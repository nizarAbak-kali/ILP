package fr.upmc.ilp.ilp1.interfaces;

public interface IASTprogram extends IAST {
    IASTsequence getBody ();
}
